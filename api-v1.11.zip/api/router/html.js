module.exports = [
	{
		name: "接口文档",
		path: "api",
	}, {
		name: "帮助",
		path: "help",
	}
]