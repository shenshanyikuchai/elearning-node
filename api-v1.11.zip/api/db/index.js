const logs = require('./logs');
const getLogs = require('./getLogs');
module.exports = {
	logs,
	getLogs
}