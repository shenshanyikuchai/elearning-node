/*
*  保存帖子
*/

module.exports = async(ctx, next) => {
	await next();
}