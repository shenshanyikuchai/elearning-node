module.exports = async (ctx, next) => {
	ctx.body = '<html><body>'
        + '<div>帮助</div>'
        + '</body></html>';
}